/**
 * wafGuard.js — Middleware "cổng WAF" cho Express.
 *
 * MỌI request đến web (trang HTML, file JS/CSS, ảnh, API...) đều đi qua đây
 * TRƯỚC khi tới router. Middleware gửi thông tin request (method, URL, body,
 * header tuỳ chọn) sang WAF Detection API (Flask, chạy riêng — mặc định
 * http://127.0.0.1:5000/api/check_request) và chờ kết quả:
 *   - API trả "allow"  -> next() cho request đi tiếp
 *   - API trả "block"  -> trả 403 ngay, request KHÔNG tới router/DB
 *   - API lỗi/timeout  -> tuỳ WAF_FAIL_MODE:
 *        closed (mặc định): trả 503, không cho qua (an toàn hơn)
 *        open             : cho qua nhưng ghi cảnh báo
 *
 * Cấu hình qua biến môi trường (.env):
 *   WAF_API_URL        mặc định http://127.0.0.1:5000
 *   WAF_FAIL_MODE      closed | open                  (mặc định closed)
 *   WAF_TIMEOUT_MS     mặc định 5000
 *   WAF_CHECK_HEADERS  danh sách header gửi kèm để kiểm tra, vd "user-agent,cookie"
 *                      (mặc định rỗng — model hay báo nhầm chuỗi User-Agent/URL đầy đủ)
 *   WAF_ENABLED        đặt "false" để tắt hẳn (chỉ dùng khi debug)
 */

const WAF_API_URL = (process.env.WAF_API_URL || "http://127.0.0.1:5000").replace(/\/+$/, "");
const CHECK_ENDPOINT = `${WAF_API_URL}/api/check_request`;
const FAIL_MODE = (process.env.WAF_FAIL_MODE || "closed").toLowerCase();
const TIMEOUT_MS = Number(process.env.WAF_TIMEOUT_MS || 5000);
const ENABLED = (process.env.WAF_ENABLED || "true").toLowerCase() !== "false";
const CHECK_HEADERS = (process.env.WAF_CHECK_HEADERS || "")
  .split(",")
  .map((h) => h.trim().toLowerCase())
  .filter(Boolean);

const LABELS = {
  sqli: "SQL Injection",
  xss: "Cross-Site Scripting (XSS)",
  "path-traversal": "Path Traversal",
};

function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[c]);
}

function hasBody(body) {
  if (body == null) return false;
  if (typeof body === "string") return body.length > 0;
  if (typeof body === "object") return Object.keys(body).length > 0;
  return false;
}

/** Trình duyệt mở trang (không phải gọi API) -> trả trang HTML thay vì JSON */
function wantsHtml(req) {
  return (
    req.method === "GET" &&
    !req.path.startsWith("/api/") &&
    req.accepts(["json", "html"]) === "html"
  );
}

function sendPage(res, status, title, bodyHtml) {
  res.status(status).type("html").send(`<!doctype html>
<html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${escapeHtml(title)}</title>
<style>
 body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f1f5f9;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#0f172a}
 .box{background:#fff;max-width:560px;width:calc(100% - 32px);padding:32px;border-radius:14px;box-shadow:0 10px 30px rgba(15,23,42,.08);border-top:6px solid #dc2626}
 h1{margin:0 0 8px;font-size:22px} p{color:#475569;line-height:1.5}
 dl{display:grid;grid-template-columns:max-content 1fr;gap:6px 14px;font-size:14px;margin:18px 0}
 dt{color:#64748b} dd{margin:0;font-family:ui-monospace,Consolas,monospace;word-break:break-all}
 a{color:#2563eb}
</style></head><body><div class="box">${bodyHtml}</div></body></html>`);
}

function block(req, res, verdict) {
  const label = LABELS[verdict.attack_type] || verdict.attack_type || "không xác định";
  const prob = verdict.malicious_probability != null
    ? `${(verdict.malicious_probability * 100).toFixed(2)} %`
    : "-";
  const source = verdict.matched_part ? verdict.matched_part.source : null;

  console.warn(
    `[WAF] BLOCK ${verdict.attack_type} ${req.method} ${req.originalUrl} ` +
      `(${source}, ${prob}, id=${verdict.request_id})`
  );
  res.set("X-WAF-Status", "blocked");
  res.set("X-WAF-Request-Id", verdict.request_id || "");

  if (wantsHtml(req)) {
    return sendPage(res, 403, "Request bị chặn", `
      <h1>⛔ Request đã bị WAF chặn</h1>
      <p>Hệ thống phát hiện nội dung độc hại trong yêu cầu của bạn nên đã từ chối truy cập.</p>
      <dl>
        <dt>Loại tấn công</dt><dd>${escapeHtml(label)}</dd>
        <dt>Vị trí phát hiện</dt><dd>${escapeHtml(source || "-")}</dd>
        <dt>Xác suất độc hại</dt><dd>${escapeHtml(prob)}</dd>
        <dt>Mã request</dt><dd>${escapeHtml(verdict.request_id || "-")}</dd>
      </dl>
      <p><a href="/">← Về trang chủ</a></p>`);
  }
  return res.status(403).json({
    error: "blocked_by_waf",
    message: `Request bị WAF chặn: phát hiện ${label}`,
    attack_type: verdict.attack_type,
    matched_source: source,
    malicious_probability: verdict.malicious_probability,
    request_id: verdict.request_id,
  });
}

function unavailable(req, res, reason) {
  console.error(`[WAF] API không khả dụng (${reason}) -> chặn ${req.method} ${req.originalUrl}`);
  res.set("X-WAF-Status", "unavailable");
  if (wantsHtml(req)) {
    return sendPage(res, 503, "WAF chưa sẵn sàng", `
      <h1>WAF Detection API chưa sẵn sàng</h1>
      <p>Mọi request đều phải được API kiểm tra trước khi vào web, nhưng hiện không kết nối được
      tới <code>${escapeHtml(WAF_API_URL)}</code>. Hãy chắc chắn API đang chạy (model có thể mất vài
      giây để nạp) rồi tải lại trang.</p>`);
  }
  return res.status(503).json({
    error: "waf_unavailable",
    message: "WAF Detection API không khả dụng, request bị từ chối (fail-closed).",
  });
}

async function wafGuard(req, res, next) {
  if (!ENABLED) return next();

  const payload = {
    app: "photo-sharing",
    method: req.method,
    url: req.originalUrl,
    client_ip: req.ip,
    body: hasBody(req.body) ? req.body : null,
  };
  if (CHECK_HEADERS.length) {
    payload.headers = {};
    for (const h of CHECK_HEADERS) {
      if (typeof req.headers[h] === "string") payload.headers[h] = req.headers[h];
    }
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  let verdict;
  try {
    const r = await fetch(CHECK_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    verdict = await r.json();
  } catch (err) {
    const reason = err.name === "AbortError" ? `timeout ${TIMEOUT_MS} ms` : err.message;
    if (FAIL_MODE === "open") {
      console.warn(`[WAF] API lỗi (${reason}) -> fail-open, cho qua ${req.method} ${req.originalUrl}`);
      res.set("X-WAF-Status", "bypass");
      return next();
    }
    return unavailable(req, res, reason);
  } finally {
    clearTimeout(timer);
  }

  if (verdict.is_malicious) return block(req, res, verdict);

  res.set("X-WAF-Status", "allowed");
  res.set("X-WAF-Request-Id", verdict.request_id || "");
  return next();
}

module.exports = wafGuard;
module.exports.WAF_API_URL = WAF_API_URL;
