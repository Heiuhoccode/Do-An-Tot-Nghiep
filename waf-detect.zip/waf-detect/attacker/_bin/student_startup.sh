#!/bin/bash
# Chay trong moi terminal cua container attacker khi lab bat dau:
# mo Firefox voi 2 tab: web Photo Sharing va trang giam sat cua WAF.
firefox http://webserver:8081 http://wafapi:5000/monitor > /dev/null 2>&1 &
