#!/bin/bash
# chay sau khi tham so hoa; dam bao pcap chi doc
chmod 444 $HOME/webdetest.pcap 2>/dev/null
