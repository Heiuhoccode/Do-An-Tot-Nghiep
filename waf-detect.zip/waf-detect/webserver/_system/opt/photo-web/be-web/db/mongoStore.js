/**
 * mongoStore.js — Nguồn dữ liệu MongoDB (DB_MODE=mongo, mặc định).
 * Đây là phần truy vấn Mongoose trước đây nằm trực tiếp trong routes/.
 */
const mongoose = require("mongoose");
const dbConnect = require("./dbConnect");
const User = require("./userModel");
const Photo = require("./photoModel");

const PUBLIC_FIELDS = "_id first_name last_name location description occupation login_name";

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const users = {
  findById(id) {
    return User.findById(id).select(PUBLIC_FIELDS);
  },

  findByLoginName(login_name, { withPassword = false } = {}) {
    const query = User.findOne({ login_name });
    return withPassword ? query.select(PUBLIC_FIELDS + " password_hash") : query;
  },

  list(q) {
    const filter = {};
    if (q) {
      const rx = new RegExp(escapeRegex(q), "i");
      filter.$or = [{ first_name: rx }, { last_name: rx }];
    }
    return User.find(filter, "_id first_name last_name");
  },

  create(data) {
    return User.create(data);
  },
};

const photos = {
  async listByUser(userId) {
    const docs = await Photo.find({ user_id: userId })
      .select("_id user_id comments file_name date_time")
      .populate({
        path: "comments.user_id",
        select: "_id first_name last_name",
        model: "Users",
      });

    return docs.map((photo) => ({
      _id: photo._id,
      user_id: photo.user_id,
      file_name: photo.file_name,
      date_time: photo.date_time,
      comments: photo.comments.map((c) => ({
        _id: c._id,
        comment: c.comment,
        date_time: c.date_time,
        user: c.user_id,
      })),
    }));
  },

  async addComment(photoId, comment) {
    const photo = await Photo.findById(photoId);
    if (!photo) return false;
    photo.comments.push(comment);
    await photo.save();
    return true;
  },
};

module.exports = {
  connect: dbConnect,
  isValidId: (id) => mongoose.isValidObjectId(id),
  users,
  photos,
};
