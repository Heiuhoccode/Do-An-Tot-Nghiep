"""
admin_bot.py — Bot "quan tri vien" cho bai lab waf-backdoor-xss (chi dung trong mang lab co lap).

GET /admin/visit?photo=<id> (xem app/__init__.py) goi visit(photo_id):
  1. Tai trang anh bang tai khoan quan tri: cookie admin_token = FLAG.
  2. Mo phong script trong binh luan: neu trang co doan doc document.cookie, bot gui cookie
     toi cac dia chi host:port nam trong BOT_EXFIL_ALLOW (may thu thap tren may bao tri).

Day la mo phong don gian cho muc dich hoc tap, khong phai trinh duyet that.
Bot khong bao gio gui du lieu toi dich ngoai danh sach cho phep.
"""
import re
import urllib.request

from . import config

_URL_RE = re.compile(r"https?://([A-Za-z0-9.\-]+):(\d+)")

'''
def _read_flag():
    try:
        with open(config.BOT_FLAG_FILE, "r", encoding="utf-8", errors="replace") as fh:
            for line in fh.read().splitlines():
                if line.strip():
                    return line.strip()
    except OSError:
        pass
    return ""
'''

_PLACEHOLDER = "@FLAGVAL@"


class FlagError(RuntimeError):
    """Loi cau hinh flag: file thieu, rong, hoac chua duoc Labtainer thay the."""


def _read_flag():
    path = config.BOT_FLAG_FILE
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            lines = [ln.strip() for ln in fh.read().splitlines() if ln.strip()]
    except OSError as exc:
        raise FlagError("khong doc duoc %s (%s)" % (path, exc.strerror or exc))
    if not lines:
        raise FlagError("file %s rong" % path)
    if _PLACEHOLDER in lines[0]:
        raise FlagError("flag chua duoc Labtainer thay the trong %s" % path)
    return lines[0]

def _get(url, cookie=None):
    headers = {"Cookie": cookie} if cookie else {}
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=config.BOT_TIMEOUT) as resp:
        return resp.read().decode("utf-8", errors="replace")


def visit(photo_id):
    """Tra ve danh sach dich da gui cookie toi."""
    flag = _read_flag()
    print("[BOT] visit photo=%s" % photo_id, flush=True)
    page = _get("http://127.0.0.1:%d/photos/%s" % (config.PORT, photo_id),
                cookie="auth=" + flag)
    sent = []
    if "document.cookie" not in page:
        return sent
    for m in _URL_RE.finditer(page):
        target = "%s:%s" % (m.group(1), m.group(2))
        if target not in config.BOT_EXFIL_ALLOW:
            print("[BOT] bo qua dich ngoai danh sach: %s" % target, flush=True)
            continue
        _get("http://%s/?c=%s" % (target, flag))
        print("[BOT] exfil -> %s" % target, flush=True)
        sent.append(target)
    return sent
