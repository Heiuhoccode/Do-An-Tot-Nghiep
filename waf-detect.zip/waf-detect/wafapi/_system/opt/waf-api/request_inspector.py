"""
request_inspector.py
====================
Tach mot HTTP request (do Web gui sang) thanh danh sach cac "doan van ban"
de dua vao pipeline WAF (waf_detector.py).

Vi sao khong dua nguyen URL "/api/user/list" vao model?
    Qua thu nghiem, model danh dau gan nhu MOI chuoi bat dau bang "/" (vd
    "/users", "/favicon.ico") la path-traversal, vi trong tap train nhom
    `url_path` gan nhu toan la mau tan cong. Trong khi do dang "request line"
    kieu HTTP/CSIC2010 ("GET /api/user/list?q=abc") lai duoc phan loai rat
    tot: request binh thuong -> norm, payload SQLi/XSS/LFI (ke ca URL-encode)
    -> tan cong. Vi vay URL luon duoc gui o dang "<METHOD> <path?query>".

Cac doan duoc kiem tra:
    request_line           "GET /api/user/search?q=%27%20OR%201%3D1--"
    request_line_decoded   ban da URL-decode (1-2 lan) neu khac ban goc
    query.<ten>            gia tri tung tham so query string (da decode)
    body.<duong_dan>       gia tri chuoi trong body (JSON / form), lam phang
    header.<ten>           (tuy chon) cac header Web chon gui sang
"""

import re
from urllib.parse import parse_qsl, unquote, urlsplit

MAX_PARTS = 64          # gioi han so doan / request (tranh body qua lon lam cham API)
MAX_TEXT_LEN = 4000     # cat bot moi doan (model chi doc toi max_len token dau)
_SIMPLE_KEY = re.compile(r"^[A-Za-z0-9_.\-\[\]]{1,64}$")


def _clip(text):
    text = str(text)
    return text[:MAX_TEXT_LEN]


def _flatten(value, prefix, out):
    """Lam phang body JSON/form thanh cac cap (duong_dan, chuoi)."""
    if len(out) >= MAX_PARTS:
        return
    if isinstance(value, dict):
        for k, v in value.items():
            key = str(k)
            # ten key bat thuong (vd chua dau nhay, $ne, <script>) cung la dau vao nguoi dung
            if not _SIMPLE_KEY.match(key):
                out.append((f"{prefix}.<key>", key))
            _flatten(v, f"{prefix}.{key}", out)
    elif isinstance(value, (list, tuple)):
        for i, v in enumerate(value):
            _flatten(v, f"{prefix}[{i}]", out)
    elif isinstance(value, str):
        if value.strip():
            out.append((prefix, value))
    # so / bool / None: khong mang payload van ban -> bo qua


def build_parts(method, url, body=None, headers=None):
    """Tra ve list[(nguon, van_ban)] da loai trung lap, giu thu tu."""
    method = (method or "GET").upper()
    url = url or "/"
    parts = [("request_line", f"{method} {url}")]

    once = unquote(url)
    if once != url:
        parts.append(("request_line_decoded", f"{method} {once}"))
        twice = unquote(once)
        if twice != once:  # bat payload double-encode (%2527 ...)
            parts.append(("request_line_decoded2", f"{method} {twice}"))

    query = urlsplit(url).query
    if query:
        for k, v in parse_qsl(query, keep_blank_values=False):
            if not _SIMPLE_KEY.match(k):
                parts.append(("query.<key>", k))
            if v.strip():
                parts.append((f"query.{k}", v))

    if body not in (None, "", {}, []):
        _flatten(body, "body", parts)

    if headers:
        for name, value in headers.items():
            if isinstance(value, str) and value.strip():
                parts.append((f"header.{name.lower()}", value))

    seen, unique = set(), []
    for source, text in parts:
        text = _clip(text)
        if text in seen:
            continue
        seen.add(text)
        unique.append((source, text))
        if len(unique) >= MAX_PARTS:
            break
    return unique
