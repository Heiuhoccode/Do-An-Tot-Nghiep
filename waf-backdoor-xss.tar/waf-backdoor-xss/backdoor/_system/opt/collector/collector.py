#!/usr/bin/env python3
"""
collector.py — May thu thap du lieu gui ve cho bai waf-backdoor-xss.
Chi nghe trong mang lab (cong 9000). Moi request ghi mot dong vao nhat ky.
"""
import datetime
import http.server

LOG = "/var/log/backdoor/collector.log"


class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG, "a", encoding="utf-8") as fh:
            fh.write("%s from=%s %s\n" % (ts, self.client_address[0], self.path))
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(b"ok\n")

    def log_message(self, fmt, *args):
        pass  # khong in log mac dinh; da ghi o LOG


if __name__ == "__main__":
    http.server.ThreadingHTTPServer(("0.0.0.0", 9000), Handler).serve_forever()
