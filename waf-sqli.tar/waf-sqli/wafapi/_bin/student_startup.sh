#!/bin/bash
# Mo Firefox tai trang giam sat WAF khi API da nap xong model.
(
  sudo mount -o remount,size=1g /dev/shm
  for i in $(seq 1 120); do
    curl -s -o /dev/null http://172.30.0.30:5000/api/health && break
    sleep 2
  done
  firefox --new-instance http://172.30.0.30:5000/monitor
) > /dev/null 2>&1 &
