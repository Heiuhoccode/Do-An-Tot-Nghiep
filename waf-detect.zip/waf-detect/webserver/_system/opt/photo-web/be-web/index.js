require("dotenv").config();
const path = require("path");
const fs = require("fs");
const express = require("express");
const cors = require("cors");
// const dbConnect = require("./db/dbConnect");
const store = require("./db/store");
const wafGuard = require("./middleware/wafGuard");
const UserRouter = require("./routes/UserRouter");
const PhotoRouter = require("./routes/PhotoRouter");

const app = express();
const PORT = Number(process.env.PORT || 8081);
const FE_BUILD = path.resolve(process.env.FE_BUILD_DIR || path.join(__dirname, "../fe-web/build"));

store.connect();

// 1) Parse body trước để WAF đọc được dữ liệu form/JSON
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));

// 2) CỔNG WAF: mọi request phía sau dòng này đều đã được WAF Detection API kiểm tra
app.use(wafGuard);

app.use(cors());

// 3) API của web
app.use("/api/user", UserRouter);
app.use("/api/photosOfUser", PhotoRouter);
app.get("/api", (request, response) => {
  response.send({ message: "Hello from photo-sharing app API!" });
});
app.use("/api", (request, response) => {
  response.status(404).send({ message: "API not found" });
});

// 4) Ảnh
app.use("/public", express.static(path.join(__dirname, "public/images")));

// 5) Giao diện React (bản build) — cũng đi qua WAF như mọi request khác
if (fs.existsSync(path.join(FE_BUILD, "index.html"))) {
  app.use(express.static(FE_BUILD));
  app.get("/{*splat}", (request, response) => {
    response.sendFile(path.join(FE_BUILD, "index.html"));
  });
} else {
  app.get("/", (request, response) => {
    response
      .status(200)
      .send(
        "Chưa có bản build giao diện. Chạy `npm run build` trong thư mục fe-web " +
        "(hoặc dùng start.bat) rồi khởi động lại web."
      );
  });
}

// Lỗi parse JSON / lỗi khác
app.use((err, request, response, next) => {
  if (err.type === "entity.parse.failed") {
    return response.status(400).send({ message: "Body JSON không hợp lệ" });
  }
  console.error(err);
  response.status(500).send({ message: "Server error" });
});

app.listen(PORT, () => {
  console.log(`[WEB] Photo Sharing đang chạy tại http://localhost:${PORT}`);
  console.log(
    `[WEB] Nguồn dữ liệu: ${store.mode === "local" ? "local (modelData/models.js, lưu trong RAM)" : "MongoDB (DB_URL)"}`
  );
  console.log(`[WEB] Mọi request đều được kiểm tra bởi WAF API: ${wafGuard.WAF_API_URL}`);
});
