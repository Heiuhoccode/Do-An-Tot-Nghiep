
import os
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
USERS_FILE = os.path.join(BASE_DIR, "users.txt")
CURRENT_USER_FILE = os.path.join(BASE_DIR, "currentuser.txt")

def user_register( username , password ) :

   
    with open(USERS_FILE, "r") as file:
        users = file.readlines()
    
    # Check if the username is already exists
    for user in users:
        stored_username, stored_password = user.strip().split(",")
        if stored_username == username :
            print("\nUser Name Already Exists")
            return False
    
    with open(USERS_FILE, "a") as file:
        file.write(f"{username},{password}\n")
    print("Registration successful!")
    
    return True


def user_login( username , password ) :
    
    # Read users from the users.txt file
    with open(USERS_FILE, "r") as file:
        users = file.readlines()
    
    # Check if the username and password match
    for user in users:
        stored_username, stored_password = user.strip().split(",")
        if stored_username == username and stored_password == password:
            print("Login successful!")
            return True
    print("Invalid username or password!")
    return False
    
def put_currentuser( username ) :
    with open(CURRENT_USER_FILE, "w") as file:
        file.write(username)
        
def get_currentuser( ) :
    with open(CURRENT_USER_FILE, "r") as file:
        currentuser = file.read()
    return currentuser
    


