# Tich hop pipeline WAF 2 tang vao Detection

Ghi chu nay tom tat nhung gi da duoc thay doi khi tich hop ket qua train
(`waf_checkpoints.zip`, retrain tren `dataset_cleaned_augmented_v2.csv`)
vao project `SQL-Injection-Detection`.

> **Cap nhat (retrain v2.0):** Ban nay THAY THE cap **CNN + SVM** truoc do
> bang cap model moi **CNN (Stage 1) + LightGBM (Stage 2)**, lay tu
> `waf_checkpoints/production/` (`config_hash = da49fcde`,
> `training_date = 2026-09-17T18:53:30`, `version = v2.0`). Day la ban
> retrain SAU KHI dataset duoc bo sung them 1.800 dong `path-traversal`
> (PHP wrapper/file nhay cam tran/encoding hiem) va 700 dong `sqli`
> (tautology khong dau nhay/comment-split) de sua 2 diem yeu phat hien qua
> 4 batch `run_testcases.py`/`_1`/`_2`/`_3` — xem lich su hoi thoai voi
> Claude de biet chi tiet ca 2 lan augment dataset.

> **Cap nhat (22/09/2026):** Ban nay THAY MODEL bang checkpoint retrain
> moi nhat, lay tu `waf_checkpoints_CNN_LightGBM_v2/production/`
> (`config_hash = 29141f95`, `training_date = 2026-09-22T06:54:17`).
> Van la cap **CNN (Stage 1) + LightGBM (Stage 2)** — KHONG doi kien
> truc, chi la ban retrain moi hon voi so lieu tot hon ban `da49fcde`
> (17/09) dang deploy truoc do: `e2e_f1_macro` test 0.9857 → 0.9953,
> `attack_fpr` test 0.00086 → 0.00051, `s1_f1` 0.9929 → 0.9934,
> `attack_recall` gan nhu khong doi (0.9884 → 0.9885). `max_len` doi tu
> 665 → 679 (tokenizer.pkl di kem cung duoc thay nen khop nhau). Vi
> `stage1_is_dl`/`stage2_is_dl`/ten model khong doi so voi ban truoc,
> **khong can sua `waf_detector.py`** — dung dung pattern "swap file
> trong `waf_models/`" da ghi trong muc 3.

## 1. Model duoc dung

| Stage | Model | Loai | Metric tren test set (`waf_models/PRODUCTION_METRICS.txt`) |
|-------|-------|------|---------------------------------------------------------------|
| 1 | CNN | Deep Learning, nhi phan | s1_f1 = 0.9934 |
| 2 | LightGBM | Machine Learning, 3 lop (TF-IDF char 1-3 gram) | macro F1 (e2e) = 0.9953, attack_recall = 0.9885, attack_fpr = 0.00051 |

Threshold: **0.35184285044670105** (threshold_before_retrain_calibration
= 0.4424417018890381).

Confusion matrix tren test set (230.661 dong, nhan
`['norm','path-traversal','sqli','xss']`):

```
                precision    recall  f1-score   support
          norm       1.00      1.00      1.00    175991
path-traversal       1.00      1.00      1.00      3284
          sqli       1.00      0.99      0.99     48652
           xss       0.99      1.00      0.99      2734
```

So voi ban truoc (17/09), `path-traversal` da len 1.00/1.00 va macro F1
tong the cai thien ro (0.9857 → 0.9953). Diem yeu lon nhat con lai van
la `sqli` bi doan nham thanh `norm` (622/48.652 dong tren tap test nay).
**Van nen tu chay lai 4 file `run_testcases.py`/`_1`/`_2`/`_3`** de doi
chieu thuc te voi ban truoc, dac biet nhom payload PHP-wrapper/encoding
hiem va SQLi tautology da biet la diem yeu.

## 2. LightGBM co `predict_proba` - KHONG gap lai bug SVM lan truoc

Khac voi SVM (`LinearSVC`, khong co `predict_proba`) da gay crash o ban
truoc, `LightGBM` (qua sklearn wrapper `LGBMClassifier`) CO san
`predict_proba()`, nen `waf_detector.py` dung nhanh predict_proba binh
thuong cho Stage 2 - KHONG can nhanh xap xi `decision_function -> softmax`
da them de xu ly SVM truoc do (nhanh do van con trong code, chi khong duoc
kich hoat, de an toan neu lan retrain sau lai chon SVM/model khac thieu
predict_proba).

## 3. File da them / sua trong project

```
SQL-Injection-Detection-main/
├── waf_models/                    # SUA (22/09) - copy tu waf_checkpoints_CNN_LightGBM_v2/production/
│   ├── stage1_CNN.keras           #   SUA - ban CNN retrain 22/09 (config_hash 29141f95)
│   ├── stage2_LightGBM.pkl        #   SUA - ban LightGBM retrain 22/09 (cung cap, so tot hon)
│   ├── tokenizer.pkl              #   SUA - max_len 665 → 679
│   ├── tfidf_vectorizer.pkl       #   SUA
│   ├── config.pkl                 #   SUA - threshold 0.3447 → 0.3518, cac key khac giu nguyen dang
│   ├── attack_type_mapping.pkl    #   SUA (noi dung khong doi: sqli:0, xss:1, path-traversal:2)
│   └── PRODUCTION_METRICS.txt     #   SUA - classification_report + confusion matrix ban 22/09
├── waf_detector.py                # KHONG DOI - van la CNN(DL)+LightGBM(non-DL) nhu ban truoc,
│                                     tu doc config.pkl nen khong can sua code
├── requirements.txt                # KHONG DOI (van con `lightgbm` tu lan truoc)
├── app.py, templates/index.html, api_client.py, run_testcases*.py  # KHONG DOI
└── legacy_model/                  # KHONG DOI
```

## 4. Cach chay

```bash
cd SQL-Injection-Detection-main
pip install -r requirements.txt
python app.py
```

Sau do chay lai ca 4 file test (`run_testcases.py`, `run_testcases_1.py`,
`run_testcases_2.py`, `run_testcases_3.py`) de doi chieu voi ket qua lan
truoc, dac biet cot Path Traversal (batch 2/3) va SQLi (batch 3).

## 5. Da kiem tra (moi truong khong co san TensorFlow/lightgbm that)

- `waf_detector.py`, `app.py`, `api_client.py`, `run_testcases*.py`: pass
  `py_compile` (khong doi tu lan truoc).
- Da doi chieu `config.pkl` moi (22/09, `config_hash=29141f95`):
  `stage1_model='CNN'`, `stage1_is_dl=True`, `stage2_model='LightGBM'`,
  `stage2_is_dl=False`, `threshold=0.35184285044670105` — dung schema
  nhu ban `da49fcde` truoc do (cung key), chi khac gia tri, nen
  `waf_detector.py` doc duoc ma khong can sua.
- Da doi chieu `attack_type_mapping.pkl` giua ban cu/moi: giong het nhau
  (`{'sqli': 0, 'xss': 1, 'path-traversal': 2}`).
- **CHUA chay duoc end-to-end voi model that** (khong co TF/lightgbm that
  trong moi truong nay, khong the pip install vi khong co mang). Ban tu
  chay `python app.py` va gui lai 4 file `waf_test_results_complex*.txt`
  de doi chieu voi ket qua ban 17/09.
