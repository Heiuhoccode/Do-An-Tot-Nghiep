#!/bin/bash
#
#  Labtainers chay script nay MOT LAN, lan dau container khoi dong (sau parameterize).
#  $1 = mat khau cua user trong container, $2 = user ID.
#  enable -> cac lan khoi dong sau service tu chay; start -> chay ngay bay gio.
#
echo $1 | sudo -S systemctl enable photo-web.service
echo $1 | sudo -S systemctl start photo-web.service
