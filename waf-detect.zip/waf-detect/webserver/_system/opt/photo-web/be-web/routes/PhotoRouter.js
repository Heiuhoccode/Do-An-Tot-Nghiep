const express = require("express");
// const mongoose = require("mongoose");
// const Photo = require("../db/photoModel");
// const User = require("../db/userModel");
const store = require("../db/store");
const router = express.Router();

// Thêm bình luận vào ảnh
router.post("/commentsOfPhoto/:photo_id", async (req, res) => {
  const { comment, user_id } = req.body || {};
  if (typeof comment !== "string" || !comment.trim()) {
    return res.status(400).send({ message: "Bình luận không được để trống." });
  }
  // if (!mongoose.isValidObjectId(req.params.photo_id) || !mongoose.isValidObjectId(user_id)) {
  if (!store.isValidId(req.params.photo_id) || !store.isValidId(user_id)) {
    return res.status(400).send({ message: "ID không hợp lệ" });
  }
  try {
    // const photo = await Photo.findById(req.params.photo_id);
    // if (!photo) return res.status(404).send({ message: "Photo not found." });
    // photo.comments.push({ comment: comment.trim(), date_time: new Date(), user_id });
    // await photo.save();
    const added = await store.photos.addComment(req.params.photo_id, {
      comment: comment.trim(),
      date_time: new Date(),
      user_id,
    });
    if (!added) return res.status(404).send({ message: "Photo not found." });
    res.status(201).send({ message: "OK" });
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: "Server error" });
  }
});

router.get("/:id", async (req, res) => {
  const userId = req.params.id;
  if (!store.isValidId(userId)) {
    return res.status(400).send({ message: "ID không hợp lệ" });
  }
  try {
    // const user = await User.findById(userId).select("_id first_name last_name");
    const user = await store.users.findById(userId);
    if (!user) {
      return res.status(400).send({
        message: "User not found.",
      });
    }

    // const photos = await Photo.find({ user_id: userId })
    //   .select("_id user_id comments file_name date_time")
    //   .populate({
    //     path: "comments.user_id",
    //     select: "_id first_name last_name",
    //     model: "Users",
    //   });

    // const result = photos.map((photo) => ({
    //   _id: photo._id,
    //   user_id: photo.user_id,
    //   file_name: photo.file_name,
    //   date_time: photo.date_time,
    //   comments: photo.comments.map((c) => ({
    //     _id: c._id,
    //     comment: c.comment,
    //     date_time: c.date_time,
    //     user: c.user_id,
    //   })),
    // }));
    const result = await store.photos.listByUser(userId);
    res.status(200).send(result);
  } catch (error) {
    console.error(error);
    res.status(400).send({ message: "Server error" });
  }
});

module.exports = router;
