/**
 * store.js — Chọn nguồn dữ liệu cho backend theo biến môi trường DB_MODE.
 *
 *   DB_MODE=mongo (mặc định) -> MongoDB qua Mongoose (DB_URL), xem db/mongoStore.js
 *   DB_MODE=local            -> dữ liệu cứng từ modelData/models.js, giữ trong RAM,
 *                               không cần MongoDB, xem db/localStore.js
 *
 * Các route chỉ gọi qua module này nên URL, mã trạng thái và dạng JSON trả về
 * giống hệt nhau ở cả hai chế độ. Giao diện chung:
 *
 *   connect()                                 khởi tạo nguồn dữ liệu
 *   isValidId(id)                             id có đúng định dạng không (24 ký tự hex)
 *   users.findById(id)                        user (trường công khai) | null
 *   users.findByLoginName(name, {withPassword}) user | null (kèm password_hash nếu cần)
 *   users.list(q)                             [{_id, first_name, last_name}], lọc theo tên nếu có q
 *   users.create(data)                        user vừa tạo
 *   photos.listByUser(userId)                 ảnh của user, comment đã kèm {_id, first_name, last_name}
 *   photos.addComment(photoId, comment)       true | false (không có ảnh)
 */
require("dotenv").config();

const MODES = ["mongo", "local"];
const mode = (process.env.DB_MODE || "mongo").trim().toLowerCase();

if (!MODES.includes(mode)) {
  throw new Error(
    `DB_MODE="${process.env.DB_MODE}" không hợp lệ, chỉ nhận: ${MODES.join(" | ")}`
  );
}

// Chỉ nạp module của chế độ đang dùng -> chế độ local không cần tới mongoose
const impl = mode === "local" ? require("./localStore") : require("./mongoStore");

module.exports = { mode, ...impl };
