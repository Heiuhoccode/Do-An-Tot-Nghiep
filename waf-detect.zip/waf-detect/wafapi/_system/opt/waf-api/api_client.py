import requests

url = "http://127.0.0.1:5000/api/check_query"
query = {"query": "' OR 1=1 --"}
response = requests.post(url, json=query)

response = response.json()

print(f"\nResponse : {response}\n")

print("Is malicious            : ", response["is_malicious"])
print("Attack type              : ", response["attack_type"])
print("Attack confidence        : ", response["attack_confidence"])
print("Malicious probability    : ", response["malicious_probability"])
print("Normal probability       : ", response["normal_probability"])
print("Attack probabilities     : ", response["attack_probabilities"])
print("Threshold                : ", response["threshold"])


# Curl : curl -X POST http://127.0.0.1:5000/api/check_query -H "Content-Type: application/json" -d '{"query": "<script>alert(1)</script>"}'
