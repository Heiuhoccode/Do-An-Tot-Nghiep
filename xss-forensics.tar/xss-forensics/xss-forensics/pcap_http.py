#!/usr/bin/env python3
"""
pcap_http.py - Cong cu phu tro doc HTTP tu file pcap (thuan Python, khong can thu vien ngoai).
Dung khi ban muon xem nhanh cac giao dich HTTP ma khong mo Wireshark/tshark.

Cach dung:
    python3 pcap_http.py webdetest.pcap                 # liet ke tat ca request + status
    python3 pcap_http.py webdetest.pcap --src 1.2.3.4   # loc theo IP nguon
    python3 pcap_http.py webdetest.pcap --full          # in ca header + body
    python3 pcap_http.py webdetest.pcap --grep passwd   # chi dong chua chuoi

Thoi gian in theo UTC (giong Wireshark khi dat mui gio UTC).
Day la cong cu phan tich forensic: no CHI doc goi tin da bat, khong gui gi ra mang.
"""
import struct, sys, datetime, argparse

def load(path):
    data = open(path, 'rb').read()
    magic = data[:4]
    if magic == b'\xa1\xb2\xc3\xd4': endian, nano = '>', False
    elif magic == b'\xd4\xc3\xb2\xa1': endian, nano = '<', False
    elif magic == b'\xa1\xb2\x3c\x4d': endian, nano = '>', True
    elif magic == b'\x4d\x3c\xb2\xa1': endian, nano = '<', True
    else:
        sys.exit('Khong phai file pcap chuan (magic=%s)' % magic.hex())
    off = 24
    pkts = []
    while off + 16 <= len(data):
        ts_sec, ts_frac, incl, orig = struct.unpack(endian + 'IIII', data[off:off+16])
        off += 16
        pkt = data[off:off+incl]; off += incl
        frac = ts_frac/1e9 if nano else ts_frac/1e6
        pkts.append((ts_sec+frac, pkt))
    return pkts

def eth(p):
    if len(p) < 14: return None
    t = struct.unpack('>H', p[12:14])[0]; pl = p[14:]
    if t == 0x8100:
        t = struct.unpack('>H', p[16:18])[0]; pl = p[18:]
    return t, pl

def ip(p):
    if len(p) < 20 or (p[0] >> 4) != 4: return None
    ihl = (p[0] & 0xf)*4; proto = p[9]
    src = '.'.join(map(str, p[12:16])); dst = '.'.join(map(str, p[16:20]))
    tot = struct.unpack('>H', p[2:4])[0]
    return proto, src, dst, (p[ihl:tot] if tot else p[ihl:])

def tcp(p):
    if len(p) < 20: return None
    sport, dport = struct.unpack('>HH', p[0:4])
    doff = (struct.unpack('>H', p[12:14])[0] >> 12)*4
    return sport, dport, p[doff:]

def fmt(t):
    return datetime.datetime.fromtimestamp(t, datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S') + ' UTC'

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('pcap')
    ap.add_argument('--src', help='loc theo IP nguon')
    ap.add_argument('--full', action='store_true', help='in ca header va body')
    ap.add_argument('--grep', help='chi in giao dich chua chuoi nay')
    a = ap.parse_args()

    streams = {}
    for ts, pkt in load(a.pcap):
        e = eth(pkt)
        if not e or e[0] != 0x0800: continue
        r = ip(e[1])
        if not r or r[0] != 6: continue
        proto, s, d, tp = r
        t = tcp(tp)
        if not t: continue
        sp, dp, payload = t
        key = (s, sp, d, dp)
        st = streams.setdefault(key, {'ts': ts, 'segs': {}})
        st['ts'] = min(st['ts'], ts)
        if payload:
            # reconstruct by arrival order (good enough for this capture)
            st['segs'][len(st['segs'])] = payload

    recs = []
    for (s, sp, d, dp), st in streams.items():
        buf = b''.join(st['segs'][i] for i in sorted(st['segs']))
        if not buf: continue
        if buf[:4] in (b'GET ', b'POST', b'PUT ', b'HEAD', b'DELE', b'OPTI'):
            kind = 'REQ'
        elif buf[:5] == b'HTTP/':
            kind = 'RESP'
        else:
            continue
        recs.append((st['ts'], kind, s, sp, d, dp, buf))
    recs.sort(key=lambda r: r[0])

    for ts, kind, s, sp, d, dp, buf in recs:
        if a.src and s != a.src: continue
        head, _, body = buf.partition(b'\r\n\r\n')
        text = head.decode('latin1', 'replace')
        first = text.split('\r\n', 1)[0]
        blob = (text + '\n' + body.decode('latin1', 'replace'))
        if a.grep and a.grep.lower() not in blob.lower(): continue
        arrow = '->' if kind == 'REQ' else '<-'
        print('%s  %-4s %s:%s %s %s:%s  %s' % (fmt(ts), kind, s, sp, arrow, d, dp, first))
        if a.full:
            for ln in text.split('\r\n')[1:]:
                if ln: print('        ' + ln)
            if body.strip():
                print('        [body] ' + body.decode('latin1', 'replace')[:500])
            print()

if __name__ == '__main__':
    main()
