"""
waf_detector.py
================
Nap pipeline WAF 2 tang (da train xong trong do an) va cung cap mot lop
`WAFDetector` (singleton) de app.py goi khi can du doan mot query.

Class nay KHONG hard-code kien truc tung tang, ma doc truc tiep
`config.pkl['stage1_is_dl']` / `config.pkl['stage2_is_dl']` (va ten model
`config.pkl['stage1_model']` / `['stage2_model']`, dung de suy ra ten file
model can nap, vd `stage1_CNN.keras`, `stage2_SVM.pkl`) de tu quyet dinh
cach nap model + vector hoa + du doan cho tung tang. Nho vay, moi lan
`selection/best_pair.json` chon mot cap khac (trong 5 model DL: MLP/RNN/
CNN/GRU/LSTM va 4 model ML: NaiveBayes/RandomForest/SVM/LightGBM) thi CHI
CAN copy lai file trong waf_models/ (khong can sua code o day), mien la
file model dat dung ten `stage{1|2}_{TenModel}.keras` (neu is_dl=True)
hoac `stage{1|2}_{TenModel}.pkl` (neu is_dl=False).

    query -> tokenizer -> pad_sequences(maxlen) -> Stage1
        neu diem Stage1 >= threshold (xem _score_stage1 - PHAI dung dung
        thang do da dung luc tune threshold trong notebook):
            -> Stage2 -> loai tan cong + xac suat/diem tung loai
        nguoc lai:
            -> binh thuong (khong chay Stage2, tiet kiem thoi gian suy luan)

Cac file trong waf_models/ (copy tu waf_checkpoints/production/):
    stage1_<TenModel>.keras|.pkl - model Stage 1 (best pair theo selection/best_pair.json)
    stage2_<TenModel>.keras|.pkl - model Stage 2
    tokenizer.pkl                - Keras Tokenizer da fit tren tap train (dung cho tang DL)
    tfidf_vectorizer.pkl         - sklearn TfidfVectorizer(char, ngram 1-3) da fit tren tap train (dung cho tang ML)
    config.pkl                   - max_len, threshold, mapping nhan, co/khong phai DL tung tang
    attack_type_mapping.pkl      - {'sqli': 0, 'xss': 1, 'path-traversal': 2}

PAD_MODE / TRUNC_MODE (DA XAC NHAN voi notebook train, ap dung cho tang DL):
    Doi chieu truc tiep voi waf_training_local.ipynb (Cell 1, ham
    predict_pipeline() - ham THAM CHIEU CHINH THUC de suy luan tren pipeline
    production, va cung la ham duoc dung de tinh moi metric bao cao). Ham do
    goi pad_sequences(..., padding='post', truncating='post') -> 'post'/'post'
    ben duoi la CHINH XAC, khong con la gia dinh.

MODEL ML KHONG CO predict_proba (QUAN TRONG - xem vu SVM gay crash):
    4 model ML co the duoc chon lam Stage1/Stage2: NaiveBayes, RandomForest,
    LightGBM deu co .predict_proba(). Rieng SVM = sklearn.svm.LinearSVC (xem
    ham get_ml_model() trong notebook) KHONG CO .predict_proba() - chi co
    .decision_function() (margin, KHONG PHAI xac suat) va .predict() (nhan
    cung). Ham THAM CHIEU predict_pipeline() trong notebook xu ly rieng 2
    truong hop:
      - Stage1 (nhi phan, co threshold): ham get_score_s1() dung
        predict_proba[:,1] neu co, khong thi dung THANG dut decision_function
        (KHONG bien doi qua sigmoid/softmax) lam "diem", va threshold trong
        config.pkl duoc do (tune_threshold) TRUC TIEP tren thang do nay. Vi
        vay _score_stage1() ben duoi PHAI mo phong dung ham get_score_s1(),
        khong duoc tu y sigmoid-hoa truoc khi so threshold, se lam sai lech
        ket qua malicious/normal so voi luc train/chon threshold.
      - Stage2 (da lop, chi argmax - khong co threshold): predict_pipeline()
        chi lay nhan cung s2_model.predict(X2)[0], KHONG tinh xac suat/do tin
        cay gi ca cho truong hop ML thieu predict_proba. De UI/API van hien
        thi duoc % cho tung loai tan cong (thay vi None hoac loi), ham
        _predict_stage_model() ben duoi TU THEM (khong nam trong notebook
        goc) buoc xap xi: softmax tren decision_function (chuan hoa ve dang
        phan bo xac suat). Vi day la xap xi CHUA duoc calibrate/kiem chung
        trong notebook train, no KHONG lam thay doi nhan du doan (argmax cua
        softmax = argmax cua decision_function goc), chi anh huong con so %
        hien thi - can hieu day la gia tri THAM KHAO, do tin cay it chinh xac
        hon so voi model DL (softmax that) hoac LightGBM/RandomForest/
        NaiveBayes (predict_proba that).
"""

import os
import pickle
import threading

import numpy as np

# -----------------------------------------------------------------------
# Cau hinh padding - da xac nhan khop voi notebook train, xem docstring o tren
# (chi dung cho tang nao la Deep Learning / dung Tokenizer)
# -----------------------------------------------------------------------
PAD_MODE = "post"      # da xac nhan khop voi waf_training_local.ipynb (predict_pipeline())
TRUNC_MODE = "post"    # da xac nhan khop voi waf_training_local.ipynb (predict_pipeline())
PAD_VALUE = 0


def _pad_sequences(sequences, maxlen, padding=PAD_MODE, truncating=TRUNC_MODE, value=PAD_VALUE):
    """Cai dat toi gian cua keras.preprocessing.sequence.pad_sequences.

    Tu viet lai (thay vi import tu tensorflow.keras / keras) de tranh phu
    thuoc vao duong dan import cu the cua tung phien ban TF/Keras (dieu nay
    hay doi giua cac version). Hanh vi tuong duong pad_sequences mac dinh
    cua Keras, chi khac o cho PAD_MODE/TRUNC_MODE duoc dat tuong minh o tren.
    """
    out = np.full((len(sequences), maxlen), value, dtype=np.int32)
    for i, seq in enumerate(sequences):
        if not seq:
            continue
        if len(seq) > maxlen:
            seq = seq[-maxlen:] if truncating == "pre" else seq[:maxlen]
        if padding == "pre":
            out[i, -len(seq):] = seq
        else:
            out[i, :len(seq)] = seq
    return out


class WAFDetector:
    """Singleton nap 1 lan duy nhat toan bo pipeline (tokenizer/tfidf + 2 model).

    Dung `get_detector()` o duoi thay vi goi `WAFDetector()` truc tiep trong
    code ung dung, de code goi khong can biet ve chi tiet singleton.
    """

    _instance = None
    _instance_lock = threading.Lock()

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            with cls._instance_lock:
                if cls._instance is None:
                    obj = super().__new__(cls)
                    obj._loaded = False
                    cls._instance = obj
        return cls._instance

    def __init__(self, model_dir=None):
        if self._loaded:
            return
        with self._instance_lock:
            if self._loaded:
                return
            self._model_dir = model_dir or os.path.join(
                os.path.dirname(os.path.abspath(__file__)), "waf_models"
            )
            self._load()
            self._loaded = True

    # ------------------------------------------------------------------
    def _load(self):
        d = self._model_dir
        if not os.path.isdir(d):
            raise FileNotFoundError(
                f"Khong tim thay thu muc model WAF: {d}. "
                "Hay chac chan da copy waf_models/ vao cung thu muc voi app.py."
            )

        with open(os.path.join(d, "config.pkl"), "rb") as f:
            self.config = pickle.load(f)

        with open(os.path.join(d, "attack_type_mapping.pkl"), "rb") as f:
            self.attack_type_mapping = pickle.load(f)  # {'sqli':0,'xss':1,'path-traversal':2}

        self.max_len = int(self.config["max_len"])
        self.threshold = float(self.config["threshold"])
        self.stage1_name = self.config["stage1_model"]          # vd "CNN", "SVM"
        self.stage2_name = self.config["stage2_model"]
        self.stage1_is_dl = bool(self.config["stage1_is_dl"])
        self.stage2_is_dl = bool(self.config["stage2_is_dl"])

        # index -> nhan, sap theo chi so lop (khong hard-code thu tu)
        self.idx_to_label = [
            label
            for label, _idx in sorted(self.attack_type_mapping.items(), key=lambda kv: kv[1])
        ]

        # Chi nap Tokenizer / TfidfVectorizer neu thuc su co tang dung den
        # (tranh phu thuoc/nap thua neu sau nay ca 2 tang cung mot loai)
        need_tokenizer = self.stage1_is_dl or self.stage2_is_dl
        need_tfidf = (not self.stage1_is_dl) or (not self.stage2_is_dl)

        self.tokenizer = None
        if need_tokenizer:
            with open(os.path.join(d, "tokenizer.pkl"), "rb") as f:
                self.tokenizer = pickle.load(f)

        self.tfidf_vectorizer = None
        if need_tfidf:
            import joblib
            self.tfidf_vectorizer = joblib.load(os.path.join(d, "tfidf_vectorizer.pkl"))

        self.stage1_model = self._load_stage_model(d, 1, self.stage1_name, self.stage1_is_dl)
        self.stage2_model = self._load_stage_model(d, 2, self.stage2_name, self.stage2_is_dl)

        # co predict_proba that hay khong (dung de biet malicious_probability
        # hien thi co phai xac suat that hay chi la xap xi tu decision_function)
        self.stage1_has_proba = self.stage1_is_dl or hasattr(self.stage1_model, "predict_proba")

        # Warm-up: lan goi predict() dau tien tren 1 model Keras vua load
        # thuong cham hon han cac lan sau (build graph). Goi truoc 1 lan de
        # request dau tien tu nguoi dung khong bi cham bat thuong. Voi model
        # ML (sklearn/LightGBM) chi phi warm-up khong dang ke nhung van goi
        # de phat hien som loi nap model/thieu thu vien.
        dummy = ["1"]
        X1 = self._stage_input(dummy, self.stage1_is_dl)
        self._score_stage1(self.stage1_model, X1, self.stage1_is_dl)
        X2 = self._stage_input(dummy, self.stage2_is_dl)
        self._predict_stage_model(self.stage2_model, X2, self.stage2_is_dl)

    @staticmethod
    def _load_stage_model(model_dir, stage_num, model_name, is_dl):
        """Nap model cho 1 tang, ten file suy ra tu config (vd stage1_CNN.keras,
        stage2_SVM.pkl) - khong hard-code ten model o day."""
        if is_dl:
            # Import tensorflow trong ham (khong o dau file) de import module
            # nay khong bat buoc phai co san tensorflow (vi du khi ca 2 tang
            # deu la model ML thi khong can tensorflow chut nao).
            import tensorflow as tf
            path = os.path.join(model_dir, f"stage{stage_num}_{model_name}.keras")
            return tf.keras.models.load_model(path, compile=False)
        else:
            import joblib
            path = os.path.join(model_dir, f"stage{stage_num}_{model_name}.pkl")
            return joblib.load(path)

    # ------------------------------------------------------------------
    def _stage_input(self, texts, is_dl):
        """Vector hoa dau vao cho 1 tang, tuy is_dl: DL -> tokenizer + pad
        sequences (giu nguyen PAD_MODE/TRUNC_MODE da xac nhan); ML -> TF-IDF
        ky tu (char n-gram, dung config tfidf_params luc train). Ket qua TF-IDF
        la sparse matrix (scipy csr) - khong ep ve dense de tiet kiem bo nho,
        moi model ML dung trong do an (NaiveBayes/RandomForest/SVM/LightGBM)
        deu nhan truc tiep sparse input."""
        if is_dl:
            sequences = self.tokenizer.texts_to_sequences(texts)
            return _pad_sequences(sequences, self.max_len)
        return self.tfidf_vectorizer.transform(texts)

    @staticmethod
    def _score_stage1(model, X, is_dl):
        """Diem Stage1 DUNG DE SO THRESHOLD - PHAI mo phong chinh xac ham
        get_score_s1() trong waf_training_local.ipynb (Cell 1), vi
        config.pkl['threshold'] duoc do (tune_threshold) TRUC TIEP tren
        thang do cua ham nay luc train. KHONG duoc tu y bien doi (sigmoid/
        softmax/chuan hoa) truoc khi so threshold - se lam sai ket qua
        malicious/normal so voi luc chon threshold trong notebook.
        """
        if is_dl:
            return np.asarray(model.predict(X, verbose=0)).ravel()
        if hasattr(model, "predict_proba"):
            return np.asarray(model.predict_proba(X))[:, 1]
        if hasattr(model, "decision_function"):
            return np.asarray(model.decision_function(X)).ravel()
        return np.asarray(model.predict(X)).astype(float)

    @staticmethod
    def _display_prob(score, has_proba):
        """Gia tri HIEN THI cho malicious_probability/normal_probability (chi
        de hien thi trong API/UI - KHONG dung de so threshold, xem
        _score_stage1). Neu score da la xac suat that (DL sigmoid hoac
        predict_proba that) thi giu nguyen; neu la diem decision_function tho
        (vd SVM, co the am/duong/ngoai [0,1]) thi ep ve [0,1] bang sigmoid de
        hien thi khong bi gay UI - day la gia tri XAP XI de hien thi, khac
        voi diem thuc te dung de quyet dinh malicious/normal."""
        score = np.asarray(score, dtype=float)
        if has_proba:
            return np.clip(score, 0.0, 1.0)
        return 1.0 / (1.0 + np.exp(-score))

    @staticmethod
    def _predict_stage_model(model, X, is_dl):
        """Du doan Stage2 (da lop, chi lay argmax - khong co threshold), tra
        ve mang xac suat/gia-xac-suat (N, so_lop):
        - DL (Keras): model.predict(X) -> softmax (N,C) that
        - ML co predict_proba (NaiveBayes/RandomForest/LightGBM): predict_proba() that
        - ML CHI co decision_function, KHONG co predict_proba (SVM =
          LinearSVC): softmax tren decision_function - XAP XI Claude tu them
          (notebook goc predict_pipeline() KHONG lam buoc nay, chi lay nhan
          cung) de UI/API van hien thi duoc %; KHONG anh huong nhan du doan
          (argmax khong doi qua softmax), chi anh huong con so % hien thi.
        - Fallback cuoi (model khong co ca predict_proba lan decision_function):
          tra ve nhan cung 1 chieu, se duoc _align_multiclass_probs xu ly
          thanh one-hot ben duoi (khong crash, nhung mat thong tin do tin cay)."""
        if is_dl:
            return model.predict(X, verbose=0)
        if hasattr(model, "predict_proba"):
            return np.asarray(model.predict_proba(X))
        if hasattr(model, "decision_function"):
            scores = np.asarray(model.decision_function(X))
            if scores.ndim == 1:
                # nhi phan (hiem gap o Stage2, nhung xu ly cho day du): ghep
                # [-score, score] roi softmax
                scores = np.stack([-scores, scores], axis=1)
            scores = scores - scores.max(axis=1, keepdims=True)
            exp = np.exp(scores)
            return exp / exp.sum(axis=1, keepdims=True)
        return np.asarray(model.predict(X))

    @staticmethod
    def _align_multiclass_probs(proba, model, mapping):
        """Sap xep lai cac cot xac suat da lop (Stage 2) theo dung thu tu idx
        trong `mapping` (label -> idx, vd {'sqli':0,'xss':1,'path-traversal':2}).

        Voi model DL (Keras) cot output da duoc dam bao dung thu tu mapping
        ngay tu luc train nen KHONG goi ham nay cho nhanh do. Voi model ML co
        thuoc tinh `classes_` (predict_proba that hoac softmax tren
        decision_function o tren deu giu nguyen thu tu classes_), dung no de
        anh xa chinh xac cot -> nhan, tranh gia dinh `classes_` da la
        [0,1,2,...] theo dung thu tu lien tuc. Neu dau vao chi la nhan cung 1
        chieu (fallback cuoi cung, model khong co predict_proba lan
        decision_function) thi chuyen thanh one-hot thay vi crash."""
        proba = np.asarray(proba)
        n_out = max(mapping.values()) + 1
        if proba.ndim == 1:
            out = np.zeros((proba.shape[0], n_out), dtype=float)
            for i, lbl in enumerate(proba.astype(int)):
                if 0 <= lbl < n_out:
                    out[i, lbl] = 1.0
            return out
        classes = getattr(model, "classes_", None)
        if classes is None:
            return proba
        classes = list(classes)
        out = np.zeros((proba.shape[0], n_out), dtype=proba.dtype)
        for label, idx in mapping.items():
            col = classes.index(idx)
            out[:, idx] = proba[:, col]
        return out

    # ------------------------------------------------------------------
    def predict(self, query: str) -> dict:
        """Du doan cho 1 query, tra ve 1 dict ket qua."""
        return self.predict_batch([query])[0]

    def predict_batch(self, queries):
        """Du doan cho danh sach query, tra ve list dict, giu nguyen thu tu.

        Moi dict co dang:
            {
                "query": str,
                "is_malicious": bool,
                "attack_type": "sqli" | "xss" | "path-traversal" | None,
                "attack_confidence": float | None,
                "malicious_probability": float,
                "normal_probability": float,
                "attack_probabilities": {"sqli": .., "xss": .., "path-traversal": ..} | None,
                "threshold": float,
            }

        (Schema giu nguyen - app.py, templates, run_testcases.py, api_client.py
        khong can sua gi them du doi model/kien truc tung tang.)
        """
        if not queries:
            return []

        X1 = self._stage_input(queries, self.stage1_is_dl)
        score1 = self._score_stage1(self.stage1_model, X1, self.stage1_is_dl)
        malicious_mask = score1 >= self.threshold
        malicious_probs_display = self._display_prob(score1, self.stage1_has_proba)

        # Chi chay Stage2 cho cac dong bi danh dau malicious (dung kien truc
        # 2 tang, tranh chay Stage2 thua tren traffic binh thuong)
        stage2_by_row = {}
        malicious_idxs = np.where(malicious_mask)[0]
        if len(malicious_idxs) > 0:
            malicious_queries = [queries[i] for i in malicious_idxs]
            X2 = self._stage_input(malicious_queries, self.stage2_is_dl)
            s2_out = self._predict_stage_model(self.stage2_model, X2, self.stage2_is_dl)
            if not self.stage2_is_dl:
                s2_out = self._align_multiclass_probs(s2_out, self.stage2_model, self.attack_type_mapping)
            else:
                s2_out = np.asarray(s2_out)
            for j, row_idx in enumerate(malicious_idxs):
                stage2_by_row[int(row_idx)] = s2_out[j]

        results = []
        for i, query in enumerate(queries):
            malicious_prob = float(malicious_probs_display[i])
            normal_prob = float(1.0 - malicious_prob)
            is_malicious = bool(malicious_mask[i])

            attack_type = None
            attack_confidence = None
            attack_probabilities = None

            if is_malicious and i in stage2_by_row:
                probs = stage2_by_row[i]
                attack_probabilities = {
                    label: float(probs[idx]) for label, idx in self.attack_type_mapping.items()
                }
                best_idx = int(np.argmax(probs))
                attack_type = self.idx_to_label[best_idx]
                attack_confidence = float(probs[best_idx])

            results.append(
                {
                    "query": query,
                    "is_malicious": is_malicious,
                    "attack_type": attack_type,
                    "attack_confidence": attack_confidence,
                    "malicious_probability": malicious_prob,
                    "normal_probability": normal_prob,
                    "attack_probabilities": attack_probabilities,
                    "threshold": self.threshold,
                }
            )

        return results


def get_detector() -> WAFDetector:
    """Tra ve instance WAFDetector dung chung cho ca process (lazy-load lan dau)."""
    return WAFDetector()
