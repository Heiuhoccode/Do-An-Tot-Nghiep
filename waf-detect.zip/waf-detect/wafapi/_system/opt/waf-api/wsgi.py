import os
from app import app, get_detector

if __name__ == "__main__" :
    port = int( os.environ.get("PORT" , 5000))
    get_detector()  # nap model truoc khi nhan request
    app.run(host="0.0.0.0", port=port, threaded=True, use_reloader=False)
