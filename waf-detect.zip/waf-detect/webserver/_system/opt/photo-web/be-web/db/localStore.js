/**
 * localStore.js — Nguồn dữ liệu cứng (DB_MODE=local), không cần MongoDB.
 *
 * Khi khởi động, nạp user / ảnh / bình luận từ modelData/models.js vào RAM,
 * giống những gì `npm run load-db` ghi vào MongoDB:
 *   - _id giữ nguyên như trong models.js (24 ký tự hex, đúng định dạng ObjectId)
 *   - tài khoản mẫu: tên đăng nhập = họ viết thường (vd "ripley"), mật khẩu "weak"
 *   - ngày giờ được chuyển thành Date -> JSON trả về dạng ISO như khi dùng MongoDB
 *
 * Đăng ký và bình luận mới chỉ được lưu trong RAM: tắt server là mất,
 * khởi động lại sẽ về đúng dữ liệu của models.js.
 */
const crypto = require("crypto");
const models = require("../modelData/models.js");
const { hashPassword } = require("../lib/password");

const SAMPLE_PASSWORD = "weak";
const PUBLIC_FIELDS = ["_id", "first_name", "last_name", "location", "description", "occupation", "login_name"];
const BRIEF_FIELDS = ["_id", "first_name", "last_name"];
const ID_RE = /^[0-9a-f]{24}$/i;

const newId = () => crypto.randomBytes(12).toString("hex");
const normId = (id) => String(id).toLowerCase();
const toDate = (v) => (v instanceof Date ? v : new Date(v));
const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

function pick(obj, keys) {
  const out = {};
  for (const k of keys) if (obj[k] !== undefined) out[k] = obj[k];
  return out;
}

// ---- Nạp dữ liệu (sao chép, không sửa object gốc trong models.js) ----
const userRows = models.userListModel().map((u) => ({
  _id: normId(u._id),
  first_name: u.first_name,
  last_name: u.last_name,
  location: u.location,
  description: u.description,
  occupation: u.occupation,
  login_name: u.last_name.toLowerCase(),
  password_hash: hashPassword(SAMPLE_PASSWORD),
}));

const photoRows = [];
for (const u of models.userListModel()) {
  for (const p of models.photoOfUserModel(u._id)) {
    photoRows.push({
      _id: normId(p._id),
      user_id: normId(p.user_id),
      file_name: p.file_name,
      date_time: toDate(p.date_time),
      comments: (p.comments || []).map((c) => ({
        _id: normId(c._id),
        comment: c.comment,
        date_time: toDate(c.date_time),
        user_id: normId(c.user._id),
      })),
    });
  }
}

const userById = new Map(userRows.map((u) => [u._id, u]));
const photoById = new Map(photoRows.map((p) => [p._id, p]));

// ---- Giao diện chung (xem db/store.js) ----
const users = {
  async findById(id) {
    const u = userById.get(normId(id));
    return u ? pick(u, PUBLIC_FIELDS) : null;
  },

  async findByLoginName(login_name, { withPassword = false } = {}) {
    const u = userRows.find((x) => x.login_name === login_name);
    if (!u) return null;
    return pick(u, withPassword ? [...PUBLIC_FIELDS, "password_hash"] : PUBLIC_FIELDS);
  },

  async list(q) {
    let rows = userRows;
    if (q) {
      const rx = new RegExp(escapeRegex(q), "i");
      rows = rows.filter((u) => rx.test(u.first_name || "") || rx.test(u.last_name || ""));
    }
    return rows.map((u) => pick(u, BRIEF_FIELDS));
  },

  async create(data) {
    if (userRows.some((u) => u.login_name === data.login_name)) {
      throw new Error(`login_name "${data.login_name}" đã tồn tại`);
    }
    const u = {
      _id: newId(),
      ...pick(data, PUBLIC_FIELDS.filter((k) => k !== "_id")),
      password_hash: data.password_hash,
    };
    userRows.push(u);
    userById.set(u._id, u);
    return pick(u, PUBLIC_FIELDS);
  },
};

const photos = {
  async listByUser(userId) {
    const id = normId(userId);
    return photoRows
      .filter((p) => p.user_id === id)
      .map((p) => ({
        _id: p._id,
        user_id: p.user_id,
        file_name: p.file_name,
        date_time: p.date_time,
        comments: p.comments.map((c) => {
          const author = userById.get(c.user_id);
          return {
            _id: c._id,
            comment: c.comment,
            date_time: c.date_time,
            // như populate() của Mongoose: user không còn tồn tại -> null
            user: author ? pick(author, BRIEF_FIELDS) : null,
          };
        }),
      }));
  },

  async addComment(photoId, { comment, date_time, user_id }) {
    const p = photoById.get(normId(photoId));
    if (!p) return false;
    p.comments.push({
      _id: newId(),
      comment,
      date_time: toDate(date_time || new Date()),
      user_id: normId(user_id),
    });
    return true;
  },
};

async function connect() {
  console.log(
    `[DB] DB_MODE=local: dùng dữ liệu cứng từ modelData/models.js ` +
      `(${userRows.length} user, ${photoRows.length} ảnh), không kết nối MongoDB. ` +
      `Đăng ký/bình luận mới chỉ lưu trong RAM.`
  );
}

module.exports = {
  connect,
  isValidId: (id) => typeof id === "string" && ID_RE.test(id),
  users,
  photos,
};
