const express = require("express");
// const mongoose = require("mongoose");
// const User = require("../db/userModel");
const store = require("../db/store");
const { hashPassword, verifyPassword } = require("../lib/password");
const router = express.Router();

// const PUBLIC_FIELDS = "_id first_name last_name location description occupation login_name";

const isText = (v) => typeof v === "string";
// const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

function publicUser(u) {
  return {
    _id: u._id,
    first_name: u.first_name,
    last_name: u.last_name,
    location: u.location,
    description: u.description,
    occupation: u.occupation,
    login_name: u.login_name,
  };
}

// Đăng ký
router.post("/register", async (req, res) => {
  const { login_name, password, first_name, last_name, location, description, occupation } =
    req.body || {};
  // Chỉ nhận chuỗi -> chặn luôn NoSQL injection kiểu {"$ne": null}
  if (![login_name, password, first_name, last_name].every((v) => isText(v) && v.trim())) {
    return res
      .status(400)
      .send({ message: "Cần nhập đủ tên đăng nhập, mật khẩu, họ và tên." });
  }
  try {
    // const exists = await User.findOne({ login_name: login_name.trim() });
    const exists = await store.users.findByLoginName(login_name.trim());
    if (exists) return res.status(400).send({ message: "Tên đăng nhập đã tồn tại." });
    const user = await store.users.create({
      login_name: login_name.trim(),
      password_hash: hashPassword(password),
      first_name: first_name.trim(),
      last_name: last_name.trim(),
      location: isText(location) ? location : "",
      description: isText(description) ? description : "",
      occupation: isText(occupation) ? occupation : "",
    });
    res.status(201).send(publicUser(user));
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: "Server error" });
  }
});

// Đăng nhập
router.post("/login", async (req, res) => {
  const { login_name, password } = req.body || {};
  if (!isText(login_name) || !isText(password) || !login_name.trim()) {
    return res.status(400).send({ message: "Cần nhập tên đăng nhập và mật khẩu." });
  }
  try {
    const user = await store.users.findByLoginName(login_name.trim(), { withPassword: true });
    // const user = await User.findOne({ login_name: login_name.trim() }).select(
    //   PUBLIC_FIELDS + " password_hash"
    // );
    if (!user || !verifyPassword(password, user.password_hash)) {
      return res.status(401).send({ message: "Sai tên đăng nhập hoặc mật khẩu." });
    }
    res.status(200).send(publicUser(user));
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: "Server error" });
  }
});

// Danh sách user (có tìm kiếm ?q=)
router.get("/list", async (req, res) => {
  try {
    // const filter = {};
    // if (isText(req.query.q) && req.query.q.trim()) {
    //   const rx = new RegExp(escapeRegex(req.query.q.trim()), "i");
    //   filter.$or = [{ first_name: rx }, { last_name: rx }];
    // }
    // const users = await User.find(filter, "_id first_name last_name");
    const q = isText(req.query.q) ? req.query.q.trim() : "";
    const users = await store.users.list(q);
    res.json(users);
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: "Server error" });
  }
});

router.get("/:id", async (req, res) => {
  // if (!mongoose.isValidObjectId(req.params.id)) {
  if (!store.isValidId(req.params.id)) {
    return res.status(400).send({ message: "ID không hợp lệ" });
  }
  try {
    // const user = await User.findById(req.params.id).select(PUBLIC_FIELDS);
    const user = await store.users.findById(req.params.id);
    if (!user) return res.status(404).send({ message: "User not found." });
    res.json(user);
  } catch (error) {
    res.status(400).send({ message: "Server error" });
  }
});

module.exports = router;
