const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  first_name: { type: String },
  last_name: { type: String },
  location: { type: String },
  description: { type: String },
  occupation: { type: String },
  // Tài khoản đăng nhập (user cũ trong DB không có 2 trường này vẫn hoạt động bình thường)
  login_name: { type: String, index: { unique: true, sparse: true } },
  password_hash: { type: String, select: false },
});

module.exports = mongoose.model.Users || mongoose.model("Users", userSchema);
