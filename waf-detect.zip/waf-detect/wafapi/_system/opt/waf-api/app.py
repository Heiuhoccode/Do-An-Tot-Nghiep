import os
import threading
import time
import uuid
from collections import Counter, OrderedDict, deque
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify

import users
from request_inspector import build_parts
from waf_detector import get_detector

app = Flask(__name__)
app.secret_key = '123456789'  # Needed for flash messages


# ---------------------------------------------------------------------------
# Suy luan an toan khi nhieu request den cung luc (Flask threaded=True)
# + cache ket qua (model la ham xac dinh: cung chuoi -> cung ket qua), nho do
# cac request lap lai (file tinh, anh, /api/user/list ...) tra loi rat nhanh.
# ---------------------------------------------------------------------------
_predict_lock = threading.Lock()
_cache_lock = threading.Lock()
_CACHE_MAX = 5000
_cache = OrderedDict()


def predict_texts(texts):
    """Du doan cho list chuoi, co cache LRU + khoa (Keras khong an toan da luong)."""
    results = [None] * len(texts)
    missing = []
    with _cache_lock:
        for i, t in enumerate(texts):
            hit = _cache.get(t)
            if hit is not None:
                _cache.move_to_end(t)
                results[i] = hit
            else:
                missing.append(i)
    if missing:
        todo = list(dict.fromkeys(texts[i] for i in missing))
        with _predict_lock:
            fresh = get_detector().predict_batch(todo)
        by_text = {r["query"]: r for r in fresh}
        with _cache_lock:
            for t, r in by_text.items():
                _cache[t] = r
                if len(_cache) > _CACHE_MAX:
                    _cache.popitem(last=False)
        for i in missing:
            results[i] = by_text[texts[i]]
    return results


def predict_one(text):
    return predict_texts([text])[0]


# ---------------------------------------------------------------------------
# Nhat ky cac request Web gui sang (de xem tren trang /monitor)
# ---------------------------------------------------------------------------
_log_lock = threading.Lock()
_logs = deque(maxlen=500)
_stats = Counter()
_started_at = datetime.now().isoformat(timespec="seconds")


def _record(entry):
    with _log_lock:
        _logs.appendleft(entry)
        _stats["total"] += 1
        if entry["blocked"]:
            _stats["blocked"] += 1
            _stats["type:" + (entry["attack_type"] or "unknown")] += 1
        else:
            _stats["allowed"] += 1


def _fmt_pct(value):
    """Dinh dang xac suat (0..1) thanh chuoi phan tram de hien thi tren giao dien."""
    if value is None:
        return "-"
    return f"{round(value * 100, 2)} %"


@app.route('/')
@app.route('/login')
def home():
    return render_template('login.html')


@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    print("\nUser Name : ", username)
    print("\nPassword  : ", password)

    user_login = users.user_login(username, password)

    if user_login == True:
        users.put_currentuser(username)
        return render_template('index.html', username=username)
    else:
        error_message = 'Invalid username or password. Please try again.'
        return render_template('login.html', error=error_message)


@app.route('/register')
def return_register():
    print("\n RETURN REGISTER \n")
    return render_template('register.html')


@app.route('/register', methods=['POST'])
def register():
    username = request.form['username']
    password = request.form['password']

    print("\nUser Name : ", username)
    print("\nPassword  : ", password)

    user_register = users.user_register(username, password)

    if user_register == True:
        users.put_currentuser(username)
        return render_template('index.html', username=username)
    else:
        error_message = 'Username Already Exists , Please try again.'
        return render_template('register.html', error=error_message)


@app.route('/index', methods=['POST'])
def index():
    sql_query = request.form['query']

    print("\nUSER      : ", users.get_currentuser())
    print("\nQuery     : ", sql_query)

    try:
        result = predict_one(sql_query)
    except Exception as exc:
        print("\n[WAFDetector] Loi khi du doan: ", exc)
        return render_template(
            'index.html',
            username=users.get_currentuser(),
            result=True,
            error_waf=(
                "Khong the chay pipeline WAF (kiem tra da cai tensorflow chua, "
                "va thu muc waf_models/ co day du file khong). Chi tiet: " + str(exc)
            ),
        )

    print("\n WAF Prediction Result \n")
    print(f"Is malicious          : {result['is_malicious']}")
    print(f"Attack type            : {result['attack_type']}")
    print(f"Malicious probability : {result['malicious_probability']}")

    username = users.get_currentuser()

    return render_template(
        'index.html',
        username=username,
        result=True,
        query=sql_query,
        is_malicious=result['is_malicious'],
        attack_type=result['attack_type'] or '-',
        attack_confidence=_fmt_pct(result['attack_confidence']),
        malicious_probability=_fmt_pct(result['malicious_probability']),
        normal_probability=_fmt_pct(result['normal_probability']),
        threshold=_fmt_pct(result['threshold']),
        attack_probabilities={
            k: _fmt_pct(v) for k, v in (result['attack_probabilities'] or {}).items()
        },
    )


@app.route('/api/check_query', methods=['POST'])
def is_sql_injection():

    payload = request.json
    if not payload or 'query' not in payload:
        return jsonify({"error": "Invalid input , 'query' field is required"}), 400

    sql_query = payload['query']
    print("\nQuery : ", sql_query)

    try:
        result = predict_one(sql_query)
    except Exception as exc:
        print("\n[WAFDetector] Loi khi du doan: ", exc)
        return jsonify({"error": f"WAF pipeline error: {exc}"}), 500

    print("\n WAF Prediction Result \n")
    print(f"Is malicious          : {result['is_malicious']}")
    print(f"Attack type            : {result['attack_type']}")
    print(f"Malicious probability : {result['malicious_probability']}")

    return jsonify(result), 200


# ===========================================================================
# API cho Web: moi request den Web deu duoc Web gui sang day de kiem tra
# ===========================================================================
@app.route('/api/check_request', methods=['POST'])
def check_request():
    """Kiem tra MOT HTTP request ma Web vua nhan.

    Body JSON (Web gui sang):
        {
          "method": "GET",
          "url": "/api/user/search?q=abc",      # path + query string (raw)
          "body": {...} | null,                   # body da parse (JSON/form)
          "headers": {"user-agent": "..."},      # tuy chon
          "client_ip": "127.0.0.1",
          "app": "photo-sharing"
        }
    Tra ve:
        {
          "request_id", "is_malicious", "action": "block"|"allow",
          "attack_type", "malicious_probability", "matched_part": {source, value},
          "parts": [{source, value, is_malicious, attack_type, malicious_probability}],
          "latency_ms"
        }
    """
    t0 = time.perf_counter()
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict) or not payload.get("url"):
        return jsonify({"error": "Invalid input, 'url' field is required"}), 400

    method = str(payload.get("method") or "GET")
    url = str(payload.get("url"))
    body = payload.get("body")
    headers = payload.get("headers") if isinstance(payload.get("headers"), dict) else None

    parts = build_parts(method, url, body, headers)
    try:
        results = predict_texts([text for _, text in parts])
    except Exception as exc:
        print("\n[WAFDetector] Loi khi du doan: ", exc)
        return jsonify({"error": f"WAF pipeline error: {exc}"}), 500

    checked = []
    for (source, text), r in zip(parts, results):
        checked.append({
            "source": source,
            "value": text,
            "is_malicious": r["is_malicious"],
            "attack_type": r["attack_type"],
            "malicious_probability": r["malicious_probability"],
        })

    hits = [c for c in checked if c["is_malicious"]]
    worst = max(hits or checked, key=lambda c: c["malicious_probability"])
    blocked = bool(hits)
    latency_ms = round((time.perf_counter() - t0) * 1000, 1)
    request_id = uuid.uuid4().hex[:12]

    _record({
        "request_id": request_id,
        "time": datetime.now().isoformat(timespec="seconds"),
        "client_ip": payload.get("client_ip") or request.remote_addr,
        "app": payload.get("app") or "-",
        "method": method.upper(),
        "url": url,
        "blocked": blocked,
        "attack_type": worst["attack_type"] if blocked else None,
        "matched_source": worst["source"] if blocked else None,
        "matched_value": worst["value"][:300] if blocked else None,
        "malicious_probability": worst["malicious_probability"],
        "parts_checked": len(checked),
        "latency_ms": latency_ms,
    })

    tag = f"BLOCK {worst['attack_type']}" if blocked else "allow"
    print(f"[WAF] {tag:<20} {method.upper():<6} {url[:120]}  ({latency_ms} ms)")

    return jsonify({
        "request_id": request_id,
        "is_malicious": blocked,
        "action": "block" if blocked else "allow",
        "attack_type": worst["attack_type"] if blocked else None,
        "malicious_probability": worst["malicious_probability"],
        "matched_part": {"source": worst["source"], "value": worst["value"]} if blocked else None,
        "parts": checked,
        "latency_ms": latency_ms,
    }), 200


@app.route('/api/health')
def health():
    try:
        d = get_detector()
    except Exception as exc:
        return jsonify({"status": "error", "error": str(exc)}), 503
    return jsonify({
        "status": "ok",
        "stage1_model": d.stage1_name,
        "stage2_model": d.stage2_name,
        "threshold": d.threshold,
        "started_at": _started_at,
    }), 200


@app.route('/api/logs')
def get_logs():
    try:
        limit = max(1, min(500, int(request.args.get("limit", 100))))
    except ValueError:
        limit = 100
    only_blocked = request.args.get("only") == "blocked"
    with _log_lock:
        items = [e for e in _logs if e["blocked"] or not only_blocked][:limit]
        stats = dict(_stats)
    return jsonify({"stats": stats, "started_at": _started_at, "logs": items}), 200


@app.route('/monitor')
def monitor():
    return render_template('monitor.html')


if __name__ == '__main__':
    host = os.environ.get("WAF_HOST", "127.0.0.1")
    port = int(os.environ.get("WAF_PORT", 5000))
    print("[WAF] Dang nap model (lan dau co the mat vai giay)...")
    try:
        get_detector()
        print("[WAF] Model da san sang.")
    except Exception as exc:
        print("[WAF] CANH BAO: chua nap duoc model:", exc)
    print(f"[WAF] API dang chay tai http://{host}:{port}  (trang giam sat: /monitor)")
    # Tat log truy cap mac dinh cua Flask (moi request da co dong [WAF] rieng o tren)
    import logging
    logging.getLogger("werkzeug").setLevel(logging.WARNING)
    # debug=False: tranh reloader nap model 2 lan; threaded=True de xu ly song song
    app.run(host=host, port=port, debug=os.environ.get("FLASK_DEBUG") == "1",
            use_reloader=False, threaded=True)
